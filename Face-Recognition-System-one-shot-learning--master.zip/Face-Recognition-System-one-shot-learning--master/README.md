# Face-Recognition-System-one-shot-learning-
You can download trained weights from:
https://drive.google.com/file/d/1CPSeum3HpopfomUEK1gybeuIVoeJT_Eo/view
